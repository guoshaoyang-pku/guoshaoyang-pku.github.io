# 接入记录

2026-10-04 重启后原目录恢复访问；异步代码已与当前源码核对并接入。原 soa_v4 已保留 6 轮完整产物与第 7 轮部分解题记录，迁移原因和进程身份在 async_migration_checkpoint.json。

| 内容 | 当前结果 |
|---|---|
| Release | kb_science_pool_v3：四源 80/400/300/200，共 980 题；train/val/test 770/105/105。ranking_v3 来自三个已完成分片的完整 1000 题输入。 |
| 评测边界 | 独立 holdout 只覆盖 ranking_v2/v3；arch170、dataflip500 已暴露。旧实验库、corpus、实际题目与预定旧批次排除到 train；legacy seed 的完整来源仍不能恢复。 |
| 实验库 | kb_lab_pool_v3，与新 split 对齐；11,215 个候选记录、1,848 个允许数据集；holdout 的数据路径和种子均无交集。 |
| 运行实现 | 持久总结与研究、跨轮原进程、会话恢复、原子提案、冻结解题版本、报告与 Git commit 已接入。历史输入从原 run 题池按哈希读取，不加入当前 solver 池。 |
| 模型验证 | sol 真实 finish 工具调用通过；Opus 本次测试超时无工具调用，旧 run 仍有额度 403，当前选 sol 总结者。 |
| 已验证范围 | 本地子进程与假模型测试覆盖恢复和并发；真实小批量 smoke 检验模型、工具、会话和报告链路。这些工程验证不代表涨分。 |

新 run 使用 --async-agents --batch-size 30 --agent-timeout 2400 --job-workers 4 --render brief --model gpt-6.1-sol --solver-backend codex --summ-backend codex --summ-model gpt-6.1-sol --science --macro-every 5 --macro-repeats 3 --gate-z 1 --train-control --test-repeats 0，并显式指定 v3 pool、lab、seed 和历史来源。宏观审查不打开 --macro-test-readout；最终 test 待生长结束、版本冻结后读取。

报告在 run/reports；研究 repo、原会话与 checkpoint 在 run/jobs；每条 commit 保留发起与应用轮次。公网 publisher 读取真实 provenance，沿用 run viewer，每 30 分钟登记内容变化并核验线上字节。重启时使用同一配置与 run-name，旧批次、评分和冻结版本保留。

