# Source boundary

The initial archive reconstructed the saved pre-v4 loop and recorded v4 patch from session a478d791-46a6-4c3e-ba47-13b6c8c32da0 (patch record1359), baseline80ea2c5. Implementation fe38385 was verified with synthetic inputs, fake model CLIs, real local subprocesses and temporary Git repositories.

After the app restart on2026-10-04, the authoritative ArchitectureIQ checkout became readable. The current archive copies the exact settled source, documentation and tests from that checkout. LIVE_SOURCE_MANIFEST.json records every source path, byte hash, capture time and release/lab manifest pointers. Documentation now follows the live aiq_rl/docs paths. Live source and repositories were not mutated by this archival operation.

This copy includes the sampled-pool historical question lookup, explicit macro test opt-in, latest-checkpoint final evaluation fallback, retained sandbox timeout interface, release exposure isolation and current viewer implementation. It may predate subsequent scheduling fixes; compare source hashes and capture time before treating it as the latest running implementation.

No credentials, auth, private model homes, session files, experiment directories, datasets, question pools or runtime logs are in this Git archive. Real release and lab inputs remain at the manifest pointers. Holdout coverage is ranking_v2/v3 only; old arch/dataflip evidence is exposed and legacy seed provenance is incomplete.

Local tests establish engineering behavior. Root separately verified real solver/curator/research/report transport and started the new run; that transport proof does not establish a solver score gain. This archival operation performed no paid model calls, experiments or publication.
