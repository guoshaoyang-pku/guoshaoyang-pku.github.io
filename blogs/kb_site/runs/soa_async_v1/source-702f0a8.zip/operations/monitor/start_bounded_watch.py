#!/usr/bin/env python3
"""Start the saved-state watcher and at most one unacknowledged queue probe."""
import fcntl
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

ARTIFACT = Path('/Users/guoshaoyang/.codex-phybench/artifacts/kb-async-20261004')
WORKSPACE = Path('/Users/guoshaoyang/Desktop/workdir/ArchitectureIQ')
THREAD = '01a105ff-45fa-75e1-b006-fd33dc873be6'
RUNTIME_HOME = Path('/Users/guoshaoyang/.codex-phybench')
MONITOR_ROOT = Path('/Users/guoshaoyang/.local/state/codex-monitor')
MONITOR = Path('/Users/guoshaoyang/.agents/skills/codex-monitor/scripts/monitor.py')
CLI = '/Applications/Codex Phybench.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'
sys.path.insert(0, str(WORKSPACE / 'aiq_rl/tools'))
from kb_jobs import process_alive, process_identity


def read(path):
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return {}


def save(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def main():
    if Path(os.environ.get('CODEX_HOME', '')).resolve() != RUNTIME_HOME:
        raise SystemExit('Current runtime home does not match verified Phybench home')
    state_dir = ARTIFACT / 'monitor'
    state_dir.mkdir(parents=True, exist_ok=True)
    with (state_dir / 'start.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        previous = read(state_dir / 'watcher.json')
        alive = process_alive(previous.get('identity'))
        if previous and alive is None:
            raise SystemExit('Existing watcher identity could not be verified')
        if alive is False or not previous:
            with (state_dir / 'watcher.log').open('a') as log:
                process = subprocess.Popen([sys.executable, '-u', str(ARTIFACT / 'watch_live.py'),
                                            '--state-dir', str(state_dir), '--ttl', '43200'],
                                           cwd=WORKSPACE, stdin=subprocess.DEVNULL,
                                           stdout=log, stderr=log, start_new_session=True)
            identity = process_identity(process.pid)
            if not identity:
                raise SystemExit('Status watcher exited during launch')
            watcher = {'pid': process.pid, 'identity': identity}
        else:
            watcher = {'pid': previous['pid'], 'identity': previous['identity']}

        active, unacked = [], []
        for folder in MONITOR_ROOT.glob('mon_*'):
            state = read(folder / 'state.json')
            if state.get('thread') != THREAD:
                continue
            if state.get('status') in ('starting', 'watching', 'submitting') and not (folder / 'stop').exists():
                active.append(state['id'])
            if any(not (folder / f'ack_{event}.json').exists()
                   for event in range(1, state.get('submitted_events', 0) + 1)):
                unacked.append(state['id'])

        connection = sqlite3.connect('file:' + str(RUNTIME_HOME / 'queue_1.sqlite') + '?mode=ro', uri=True)
        try:
            queued = connection.execute('SELECT count(*) FROM queued_items WHERE thread_id=?', (THREAD,)).fetchone()[0]
        finally:
            connection.close()

        delivery = read(state_dir / 'delivery.json')
        if delivery.get('probe_monitor'):
            receipt = {'status': 'existing_probe_preserved', 'id': delivery['probe_monitor']}
        elif active or unacked or queued:
            receipt = {'status': 'existing_pending_preserved', 'active_monitors': active,
                       'unacked_monitors': unacked, 'queued_count': queued}
        else:
            message = ('KB 合并状态通知兼接收探针。先按本消息 argv ack，再读取 '
                       + str(state_dir / 'current.json') + '。检查一次最新实验、研究报告和发布失败；'
                       '后续变化持续写此状态文件，本通知未确认前不得再建 monitor。'
                       '记录实际接收方式；queue 接受不能证明自动唤醒或 steer。'
                       '保持正式实验与 publisher，按已授权任务继续；不重跑已保存解题，不读 test，不加主页 block。')
            result = subprocess.run([sys.executable, str(MONITOR), '--state-root', str(MONITOR_ROOT),
                                     'start', '--after', '3', '--ttl', '300', '--max-events', '1',
                                     '--codex-bin', CLI, '--thread', THREAD, '--cwd', str(WORKSPACE),
                                     '--message', message], check=True, text=True, capture_output=True, timeout=20)
            receipt = json.loads(result.stdout)
            delivery['probe_monitor'] = receipt['id']
        delivery.setdefault('automatic_receipt_verified', False)
        delivery.setdefault('actual_probe_receipt', None)
        delivery.update(mode='one queue notification plus latest status file',
                        automatic_steer_available=False, max_pending_notifications=1,
                        repeated_notification_monitor=False, watcher=watcher,
                        state_file=str(state_dir / 'current.json'), armed_at=time.time(),
                        app_server={'pid': 71058, 'transport': 'stdio', 'connectable_endpoint': None},
                        steer_documentation='https://learn.chatgpt.com/docs/app-server#steer-an-active-turn',
                        last_launch_receipt=receipt)
        save(state_dir / 'delivery.json', delivery)
        print(json.dumps(delivery, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
