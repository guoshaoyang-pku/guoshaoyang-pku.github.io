#!/usr/bin/env python3
"""Keep one current KB status file; notification delivery is separate and bounded."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import sys
import time

WORKSPACE = Path('/Users/guoshaoyang/Desktop/workdir/ArchitectureIQ')
ARTIFACT = Path('/Users/guoshaoyang/.codex-phybench/artifacts/kb-async-20261004')
sys.path.insert(0, str(WORKSPACE / 'aiq_rl/tools'))
from kb_jobs import process_alive, process_identity


def save(path, value):
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def read(path, errors):
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as error:
        errors.append({'file': str(path), 'error_type': type(error).__name__})
        return {}


def snapshot_run(name):
    run = WORKSPACE / 'aiq_rl/data/kb_scratch/kb_science_loop' / name
    errors, metrics, reports, faults = [], [], [], []
    try:
        for line in (run / 'metrics.jsonl').read_text().splitlines():
            metrics.append(json.loads(line))
    except FileNotFoundError:
        pass
    except (OSError, ValueError) as error:
        errors.append({'file': str(run / 'metrics.jsonl'), 'error_type': type(error).__name__})
    counts = Counter()
    for path in sorted((run / 'jobs').glob('J*/job.json')):
        job = read(path, errors)
        if not job:
            continue
        counts[job.get('kind', 'unknown') + ':' + job.get('status', 'unknown')] += 1
        alive = process_alive(job.get('identity')) if job.get('status') == 'running' else None
        if job.get('status') in ('failed', 'retry_wait') or alive is False:
            faults.append({'id': job.get('id'), 'kind': job.get('kind'),
                           'status': job.get('status'), 'alive': alive,
                           'attempt': job.get('attempt'),
                           'error_type': job.get('last_error_type')})
        if job.get('checkpoint_commit'):
            reports.append({key: job.get(key) for key in
                            ('id', 'report_id', 'checkpoint_commit', 'origin_epoch', 'status')})
    processes = {}
    for filename in ('launch.json', 'publisher_process.json'):
        descriptor = read(run / filename, errors)
        if descriptor.get('identity'):
            processes[filename] = {'pid': descriptor.get('pid'),
                                   'alive': process_alive(descriptor['identity'])}
    kb_paths = sorted((run / 'kb').glob('kb_[0-9][0-9][0-9][0-9].json'))
    checkpoint = read(kb_paths[-1], errors) if kb_paths else {}
    live_kb = read(run / 'kb_live.json', errors)
    kb = live_kb or checkpoint
    publication = read(run / 'publication_state.json', errors)
    publisher_fault = None
    try:
        with (run / 'publisher.log').open('rb') as stream:
            stream.seek(max(0, os.fstat(stream.fileno()).st_size - 65536))
            publisher_lines = stream.read().decode('utf-8', errors='replace').splitlines()[-16:]
        for line in publisher_lines:
            try:
                item = json.loads(line)
            except ValueError:
                continue
            if item.get('status') == 'retryable_error':
                publisher_fault = {'status': item['status'], 'error_type': item.get('error_type')}
            elif item.get('status') in ('deployed', 'unchanged'):
                publisher_fault = None
    except FileNotFoundError:
        pass
    lab_rows, nonfinite = 0, 0
    try:
        for line in (run / 'lab_experiments.jsonl').read_text().splitlines():
            row = json.loads(line)
            lab_rows += 1
            if any(isinstance(row.get(key), (int, float)) and not math.isfinite(row[key])
                   for key in ('mean', 'std')):
                nonfinite += 1
    except FileNotFoundError:
        pass
    except (OSError, ValueError) as error:
        errors.append({'file': str(run / 'lab_experiments.jsonl'), 'error_type': type(error).__name__})
    solves = {path.name: {'kb': len(list((path / 'solves').glob('*.json'))),
                         'nokb': len(list((path / 'nokb_solves').glob('*.json')))}
              for path in sorted((run / 'epochs').glob('e[0-9][0-9][0-9][0-9]'))}
    config = read(run / 'config.json', errors)
    return {'completed_epochs': len(metrics),
            'latest_epoch': max((row.get('epoch', 0) for row in metrics), default=0),
            'batch_size': config.get('batch_size'), 'planned_epochs': config.get('epochs'),
            'kb_claims': len(kb.get('claims', [])), 'kb_live_reports': len(kb.get('reports', {})),
            'kb_live_epoch': kb.get('epoch'), 'kb_live_commit': kb.get('commit_counter'),
            'kb_checkpoint_claims': len(checkpoint.get('claims', [])), 'saved_solves': solves,
            'latest_metric': metrics[-1] if metrics else None,
            'jobs_by_kind_status': dict(counts), 'faults': faults,
            'processes': processes, 'reports': reports, 'read_errors': errors,
            'publisher_retry': publisher_fault,
            'lab_metric_outputs': {'rows': lab_rows, 'nonfinite': nonfinite},
            'publication': {key: publication.get(key) for key in
                            ('git_commit', 'deployment_verified', 'pushed_at')}}


def snapshot():
    return {'checked_at': datetime.now(timezone.utc).isoformat(),
            'runs': {name: snapshot_run(name) for name in
                     ('soa_async_v1', '_async_transport_real_v3_20261004')},
            'scope': 'Saved training, job and publication state only; no test reads.',
            'delivery': {'mode': 'one queued notification plus current status file',
                         'automatic_steer_available': False,
                         'automatic_receipt_verified': False}}


def material_state(current):
    return {name: {'completed_epochs': run['completed_epochs'], 'faults': run['faults'],
                   'publisher_retry': run['publisher_retry'],
                   'main_alive': run['processes'].get('launch.json', {}).get('alive'),
                   'publisher_alive': run['processes'].get('publisher_process.json', {}).get('alive'),
                   'completed_research': run['jobs_by_kind_status'].get('research:completed', 0)}
            for name, run in current['runs'].items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state-dir', type=Path, default=ARTIFACT / 'monitor')
    parser.add_argument('--interval', type=float, default=20)
    parser.add_argument('--ttl', type=float, default=43200)
    parser.add_argument('--once', action='store_true')
    args = parser.parse_args()
    if args.interval <= 0 or args.ttl <= 0:
        parser.error('interval and ttl must be positive')
    args.state_dir.mkdir(parents=True, exist_ok=True)
    with (args.state_dir / 'watcher.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        deadline = time.monotonic() + args.ttl
        state = {'pid': os.getpid(), 'identity': process_identity(os.getpid()),
                 'started_at': time.time(), 'expires_at': time.time() + args.ttl,
                 'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                 'status': 'watching', 'queue_submissions': 0}
        stop = False

        def request_stop(signum, frame):
            nonlocal stop
            stop = True

        signal.signal(signal.SIGTERM, request_stop)
        signal.signal(signal.SIGINT, request_stop)
        previous = None
        save(args.state_dir / 'watcher.json', state)
        try:
            while not stop and time.monotonic() < deadline:
                current = snapshot()
                save(args.state_dir / 'current.json', current)
                material = material_state(current)
                if previous is not None and material != previous:
                    with (args.state_dir / 'changes.jsonl').open('a') as stream:
                        stream.write(json.dumps({'checked_at': current['checked_at'],
                                                 'state': material}, ensure_ascii=False) + '\n')
                previous = material
                if args.once:
                    print(json.dumps(current, ensure_ascii=False))
                    break
                next_read = min(time.monotonic() + args.interval, deadline)
                while not stop and time.monotonic() < next_read:
                    time.sleep(min(1, next_read - time.monotonic()))
            state['status'] = 'completed' if args.once else ('stopped' if stop else 'expired')
        except Exception as error:
            state.update(status='failed', error_type=type(error).__name__)
            raise
        finally:
            state['finished_at'] = time.time()
            save(args.state_dir / 'watcher.json', state)


if __name__ == '__main__':
    main()
