# Bounded monitor protocol snapshot

Captured from the root task instructions on 2026-10-04. This protocol records reported operational state at capture; it does not verify automatic notification receipt or persist volatile runtime state.

- The reported current app-server PID is 71058. Its transport is dedicated stdio, with no named external listener. Official `turn/steer` requires `expectedTurnId`; the implementation must not guess it or write into private pipes.
- All old manually steered events were acknowledged. Manual receipt does not establish automatic reception.
- One new queue probe, `mon_3e280800ca1d` event 1, was reported pending and unacknowledged. Queue acceptance does not prove a conversation wakeup.
- `watch_live.py` writes saved training, research-job and publication status every 20 seconds for 12 hours. It never submits queue messages and does not read final test results. The root reported watcher PID 90701; that historical PID is not a live identity guarantee.
- `start_bounded_watch.py` starts at most one probe after checking matching-thread active monitors, acknowledgments and queue entries. An existing pending notification is preserved.
- Automatic reception remains unverified. On actual receipt, follow the message acknowledgment arguments and record the actual delivery mode before claiming success.

At 2026-10-04 23:56 Asia/Shanghai, the root reported restarting only the status watcher as PID 95753 after adding live KB versus checkpoint counts, publisher retry status and nonfinite metric counts. The final reported source hash was `d6e4ff4eac8977f5c8fef039bc09bb56ce39a77ffa55c9108f82cea588815402`. PID 90701 above describes the earlier watcher. Neither reported PID is a current process identity verification. Automatic reception remained unverified and the single probe remained pending.

The archived scripts retain exact source paths and runtime-home checks. Running them requires the original workspace and runtime; this archive operation does not launch them. `current_followup.md` is a static handoff snapshot and may become stale. Credentials, current monitor state, queue database, session files and model homes are excluded.
