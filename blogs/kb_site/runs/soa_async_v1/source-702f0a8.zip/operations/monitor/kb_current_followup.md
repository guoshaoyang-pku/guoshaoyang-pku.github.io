# Current KB follow-up

Latest user instruction: stop old monitors, retain experiments/publishers, inspect current state once, prefer actual turn steer; otherwise keep at most one pending notification and continue writing status files. Do not replay old events.

All old current-thread monitors are stopped or finished; manually steered c2 event1, 5166 events1–8 and b1 event1 were acknowledged. They establish manual receipt only.

Current app-server PID71058 uses dedicated stdio, no externally connectable endpoint. Official turn/steer requires the active expectedTurnId. Do not guess IDs, write into its private pipe, start a replacement app-server, or start codex exec resume to simulate delivery.

One fallback probe only: mon_3e280800ca1d event1. Root has seen its queue receipt on disk but has NOT received the message as conversation input or acknowledged it. Keep that distinction. If it arrives, run the argv in its message, then record actual receipt mode in monitor/delivery.json before claiming any automatic delivery. No further monitor is permitted while it remains pending. The watcher never queues messages and keeps current.json updated every20 seconds for12 hours.

Current state: /Users/guoshaoyang/.codex-phybench/artifacts/kb-async-20261004/monitor/current.json
Delivery state: /Users/guoshaoyang/.codex-phybench/artifacts/kb-async-20261004/monitor/delivery.json
Watcher descriptor: same directory /watcher.json; transitions /changes.jsonl

Formal soa_async_v1 (gpt-6.1-sol, batch30,15epochs, macroevery5) and two publishers remain running. Keep original saved solves and session identities. Do not read final test; do not add homepageblocks. Research reports may be unfinished and available in the next frozen snapshot without a ready flag.

Frozen35claim render diagnostic finished on the same105newval items: noKB68.10%,brief60.00%,tool65.95%,once perarm. Tool minus noKB -2.14pt SE3.68; brief -8.10pt SE3.76; tool minusbrief+5.95pt SE2.98. No reliable sol benefit shown. Publication agent is registering this distinct diagnostic with fullKB/records/provenance; result /private/tmp/kb_frozen_publication_result.md. Never send these val examples to researchers.

Formal latest report paths are in current.json. Concrete controlled progress includes alpha/data-dependent GRU/transformer crossover, RMSprop activation×LN interaction, and a long-budget XOR SGD/AdamW reversal. Read measurements and boundaries; mechanisms require process measurements and transfer checks. Source repos/commits are part of origin epochs.
