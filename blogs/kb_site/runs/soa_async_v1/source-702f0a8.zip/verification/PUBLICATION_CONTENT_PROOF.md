# Publication content preservation proof

Captured two authoritative source files on 2026-10-04 at 16:31:19 UTC. The publisher shares identical research attachments at content-hash paths, compresses attachments larger than 256 KiB as deterministic gzip, and emits a source-path map. The viewer marks gzip downloads; its layout is unchanged.

The existing computed export proof verified all **1,678 source mappings** against the SHA256 of the complete uncompressed original bytes. Full report texts, KB/solve data and reproducible source links remain available. The two export snapshots contained 630 distinct output files totaling 58,012,119 bytes; these are snapshots taken while the run was growing, not fixed current KB or report counts.

The parent reported that 10 `test_kb_publish` tests and `node --check` passed. This archive operation copied source bytes and safe computed metadata; it did not rerun tests, call models, read held-out questions, operate publishers, change the live workspace or mutate blog Git history.

Machine-readable provenance is in `PUBLICATION_CONTENT_PROOF.json` and the updated `LIVE_SOURCE_MANIFEST.json`. Earlier source commit `0ee8e571593f1ff9e09b6a621e9b37415fd853c4`, previous archive commit `b58c06f888364ca21ecfa941ce938cc3db09f117`, their bundles and their delivery records remain preserved.
