import contextlib
import hashlib
import io
import json
import sys
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import kb_lab


class LabReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.datasets = self.root / "datasets"
        self.lab = self.root / "release_lab"
        self.pool = self.root / "questions.jsonl"
        self.split = self.root / "split.json"
        self.mock = patch.object(kb_lab, "DATASETS", self.datasets)
        self.mock.start()

    def tearDown(self):
        self.mock.stop()
        self.temp.cleanup()

    def dataset(self, family, dataset_id, seed=42):
        directory = self.datasets / family / dataset_id
        directory.mkdir(parents=True)
        (directory / "dataset_spec.json").write_text(json.dumps({"family": family, "dataset_id": dataset_id,
                    "params": {"seed": seed}, "selection_metric": "loss"}))
        for i in range(2):
            candidate = directory / "candidates/set_1" / f"c_{i}"
            (candidate / "results").mkdir(parents=True)
            (candidate / "candidate_spec.json").write_text(json.dumps({"budget": {"training_steps": 1, "batch_size": 1},
                      "model": {"type": "mlp", "width": 4, "depth": 1}, "optimizer": {"type": "sgd"}, "loss": {}}))
            (candidate / "results/summary.json").write_text(json.dumps({"selection_metric": "loss", "mean_loss": i + 1.}))

    def write_pool(self, questions):
        self.pool.write_text("".join(json.dumps(q) + "\n" for q in questions))

    def question(self, qid, source, family, group, meta=None, prompt="measured fixture"):
        return {"question_id": qid, "source": source, "family": family, "group": group,
                "messages": [{"role": "user", "content": prompt}], "meta": meta or {}}

    def build(self):
        with contextlib.redirect_stdout(io.StringIO()):
            kb_lab.build(SimpleNamespace(pool=self.pool, split=[str(self.split)], lab_dir=self.lab))

    def test_release_split_excludes_all_four_sources_and_canonical_members(self):
        sources = ("arch170", "ranking_v2", "ranking_v3", "dataflip500")
        questions = []
        mapping = {}
        for i, source in enumerate(sources):
            dataset_id, family = f"held{i}", f"family{i}"
            self.dataset(family, dataset_id)
            self.dataset(family, "safe")
            meta = ({"candidate_set": f"datasets/{family}/{dataset_id}/candidates/set_1"} if i % 2 == 0
                    else {"dataset_id": dataset_id})
            q = self.question(f"q{i}", source, family, f"original_{i}", meta)
            questions.append(q)
            mapping[q["question_id"]] = f"Gcanonical{i}"
        # Another source member in the same canonical held-out group must also stay outside the lab.
        self.dataset("extra", "same_group")
        questions.append(self.question("linked", "ranking_v3", "extra", "original_link",
                                       {"dataset_path": "datasets/extra/same_group"}))
        mapping["linked"] = mapping["q0"]
        self.write_pool(questions)
        self.split.write_text(json.dumps({"train": [], "val": ["q0", "q1"], "test": ["q2", "q3"],
                                          "group_by_question": mapping}))
        self.build()
        allowed = set((self.lab / "allowed_datasets.txt").read_text().split())
        self.assertEqual(allowed, {f"family{i}/safe" for i in range(4)})
        manifest = json.loads((self.lab / "lab_manifest.json").read_text())
        self.assertEqual(manifest["pool"]["sha256"], hashlib.sha256(self.pool.read_bytes()).hexdigest())
        self.assertEqual(manifest["splits"][0]["sha256"], hashlib.sha256(self.split.read_bytes()).hexdigest())
        self.assertEqual(len(manifest["excluded_dataset_dirs"]), 5)

    def test_runtime_split_with_canonical_groups_uses_explicit_ids_and_prompt_seeds(self):
        self.dataset("seed_family", "seed_held", 876543210)
        self.dataset("seed_family", "safe", 123)
        self.dataset("path_family", "path_held", 77)
        questions = [self.question("seed", "dataflip500", "seed_family", "old_seed_group",
                                   prompt="synthesis seed=876543210"),
                     self.question("path", "ranking_v2", "path_family", "old_path_group",
                                   {"dataset": "datasets/path_family/path_held"})]
        self.write_pool(questions)
        self.split.write_text(json.dumps({"stream": {}, "eval": ["seed"], "test": ["path"],
                                          "eval_groups": ["Gcanonical_seed", "Gcanonical_path"]}))
        self.build()
        self.assertEqual(set((self.lab / "allowed_datasets.txt").read_text().split()), {"seed_family/safe"})

    def test_legacy_runtime_group_paths_still_exclude(self):
        questions = [self.question("q", "arch170", "family", "datasets/family/held")]
        self.write_pool(questions)
        self.split.write_text(json.dumps({"eval_groups": ["datasets/family/held"]}))
        dirs, seeds = kb_lab.held_out([self.split], self.pool)
        self.assertEqual(dirs, {"family/held"})
        self.assertEqual(seeds, set())

    def test_explicit_short_and_nested_seed_matches_dataset(self):
        self.dataset("family", "held_meta", 17)
        self.dataset("family", "held_prompt", 23)
        self.dataset("family", "safe", 91)
        self.write_pool([self.question("meta", "ranking_v3", "family", "g1",
                                      {"params": {"generation": {"data_seed": 17}}}),
                         self.question("prompt", "dataflip500", "family", "g2", prompt="generated with seed=23")])
        self.split.write_text(json.dumps({"val": ["meta"], "test": ["prompt"]}))
        self.build()
        self.assertEqual(set((self.lab / "allowed_datasets.txt").read_text().split()), {"family/safe"})

    def test_runtime_eval_group_uses_adjacent_release_group_map(self):
        self.write_pool([self.question("q1", "arch170", "family", "original1",
                                      {"candidate_set": "datasets/family/held/candidates/set_1"}),
                         self.question("q2", "ranking_v2", "extra", "original2",
                                      {"dataset_id": "also_held"})])
        self.split.write_text(json.dumps({"train": [], "val": ["q1", "q2"], "test": [],
                                          "group_by_question": {"q1": "Gshared", "q2": "Gshared"}}))
        runtime = self.root / "runtime.json"
        runtime.write_text(json.dumps({"stream": {}, "eval": ["q1"], "test": [], "eval_groups": ["Gshared"]}))
        dirs, _ = kb_lab.held_out([runtime], self.pool)
        self.assertEqual(dirs, {"family/held", "extra/also_held"})

    def test_required_allowlist_refuses_missing_or_tampered_inputs_before_training_import(self):
        self.dataset("family", "safe")
        self.dataset("family", "held")
        self.write_pool([self.question("q", "arch170", "family", "datasets/family/held")])
        self.split.write_text(json.dumps({"eval": ["q"], "test": []}))
        job = {"dataset": "family/safe", "candidates": []}
        with self.assertRaisesRegex(ValueError, "allowlist or manifest is missing"):
            kb_lab.run_job(job, lab_dir=self.lab, require_allowlist=True, pool=self.pool)
        self.build()
        with self.assertRaisesRegex(ValueError, "not in the lab"):
            kb_lab.run_job({**job, "dataset": "family/held"}, lab_dir=self.lab, require_allowlist=True, pool=self.pool)
        with (self.pool).open("a") as f:
            f.write("\n")
        with self.assertRaisesRegex(ValueError, "pool hash mismatch"):
            kb_lab.run_job(job, lab_dir=self.lab, require_allowlist=True, pool=self.pool)
        with (self.lab / "allowed_datasets.txt").open("a") as f:
            f.write("family/held\n")
        with self.assertRaisesRegex(ValueError, "hash mismatch"):
            kb_lab.run_job(job, lab_dir=self.lab, require_allowlist=True)

    def test_unknown_heldout_id_and_path_traversal_fail(self):
        self.write_pool([self.question("q", "arch170", "family", "g")])
        self.split.write_text(json.dumps({"val": ["missing"], "test": []}))
        with self.assertRaisesRegex(ValueError, "absent from pool"):
            self.build()
        self.assertFalse(self.lab.exists())
        with self.assertRaisesRegex(ValueError, "dataset must"):
            kb_lab.run_job({"dataset": "../elsewhere", "candidates": []}, lab_dir=self.lab)

    def test_changed_split_refuses_old_allowlist(self):
        self.dataset("family", "safe")
        self.write_pool([self.question("q", "arch170", "family", "g")])
        self.split.write_text(json.dumps({"val": [], "test": []}))
        self.build()
        self.split.write_text(json.dumps({"val": ["q"], "test": []}))
        with self.assertRaisesRegex(ValueError, "split hash mismatch"):
            kb_lab.run_job({"dataset": "family/safe", "candidates": []}, lab_dir=self.lab,
                           require_allowlist=True, pool=self.pool)

    def test_validation_api_returns_allowlist_and_rejects_changed_pool_and_split(self):
        self.dataset("family", "safe")
        self.write_pool([self.question("q", "arch170", "family", "g")])
        self.split.write_text(json.dumps({"val": [], "test": []}))
        self.build()
        self.assertEqual(kb_lab.validate_allowlist(self.lab, self.pool), {"family/safe"})
        different_pool = self.root / "other.jsonl"
        different_pool.write_text("{}\n")
        with self.assertRaisesRegex(ValueError, "pool hash mismatch"):
            kb_lab.validate_allowlist(self.lab, different_pool)
        self.split.write_text(json.dumps({"val": ["q"], "test": []}))
        with self.assertRaisesRegex(ValueError, "split hash mismatch"):
            kb_lab.validate_allowlist(self.lab, self.pool)

    def measured_fixture(self, summary, cached, curves=None, error=None):
        self.dataset("family", "safe")
        job = {"dataset": "family/safe", "candidates": [{
            "model": {"type": "mlp", "width": 4, "depth": 1},
            "optimizer": {"type": "SGD", "lr": .001},
            "loss": {"loss_id": "mse"}, "budget": {"training_steps": 1, "batch_size": 1}}]}
        directories = []

        def save_outputs(directory):
            (directory / "results").mkdir(exist_ok=True)
            (directory / "results/summary.json").write_text(json.dumps(summary))
            if curves is not None:
                (directory / "results/curves.npz").write_bytes(curves)

        def write_candidate(spec, directory, model_type):
            directories.append(directory)
            if cached:
                save_outputs(directory)

        def fixture_ground_truth(directory, profile, dataset):
            if error is not None:
                raise error
            save_outputs(directory)
            return summary

        ground_truth = Mock(side_effect=fixture_ground_truth)
        modules = {"architecture_iq": SimpleNamespace(),
                   "architecture_iq.candidates": SimpleNamespace(),
                   "architecture_iq.candidates.generator": SimpleNamespace(write_candidate=write_candidate),
                   "architecture_iq.registry": SimpleNamespace(ensure_registries=lambda: None,
                                                               get_model_type=lambda name: name),
                   "architecture_iq.ground_truth": SimpleNamespace(),
                   "architecture_iq.ground_truth.runner": SimpleNamespace(run_ground_truth=ground_truth),
                   "architecture_iq.profile": SimpleNamespace(load_profile=lambda name: {"fixture": True})}
        with patch.dict(sys.modules, modules), patch.dict(kb_lab.os.environ), \
                patch.object(sys, "path", list(sys.path)), \
                patch.object(kb_lab.cf, "ProcessPoolExecutor", ThreadPoolExecutor):
            result = kb_lab.run_job(job, workers=1, lab_dir=self.lab)["results"][0]
        self.assertEqual(result["candidate"], job["candidates"][0])
        return result, directories[0], ground_truth

    def test_cached_measurement_preserves_failed_seed_and_curve_provenance(self):
        seeds = [{"seed": 37, "failed": False, "final_test_mse": .2},
                 {"seed": 38, "failed": True, "final_test_mse": None}]
        summary = {"selection_metric": "test_mse", "mean_test_mse": .2, "std_test_mse": 0.,
                   "failed_seeds": 1, "excluded": True, "n_seeds": 2, "base_seed": 37,
                   "seed_results": seeds}
        result, directory, ground_truth = self.measured_fixture(summary, cached=True, curves=b"fixture curves")
        ground_truth.assert_not_called()
        self.assertTrue(result["cached"])
        for key in ("failed_seeds", "excluded", "n_seeds", "base_seed", "seed_results"):
            self.assertEqual(result[key], summary[key])
        self.assertEqual(result["mean"], .2)
        self.assertEqual(result["std"], 0.)
        self.assertEqual(set(result["measurement_files"]),
                         {"candidate_spec.json", "results/summary.json", "results/curves.npz"})
        for name, metadata in result["measurement_files"].items():
            payload = (directory / name).read_bytes()
            self.assertEqual(metadata, {"path": str((directory / name).resolve()),
                                       "sha256": hashlib.sha256(payload).hexdigest(), "bytes": len(payload)})

    def test_cached_old_summary_retains_unknown_seed_fields(self):
        result, directory, ground_truth = self.measured_fixture(
            {"selection_metric": "loss", "mean_loss": .3}, cached=True)
        ground_truth.assert_not_called()
        self.assertTrue(result["cached"])
        for key in ("std", "failed_seeds", "excluded", "n_seeds", "base_seed", "seed_results"):
            self.assertIsNone(result[key])
        self.assertEqual(set(result["measurement_files"]), {"candidate_spec.json", "results/summary.json"})
        self.assertFalse((directory / "results/curves.npz").exists())

    def test_fresh_measurement_preserves_runner_seed_results_exactly(self):
        summary = {"selection_metric": "test_mse", "mean_test_mse": .2, "std_test_mse": .01,
                   "failed_seeds": 0, "excluded": False, "n_seeds": 2, "base_seed": 17,
                   "seed_results": [{"seed": 17, "failed": False, "final_test_mse": .19},
                                    {"failed": False, "final_test_mse": .21}]}
        result, directory, ground_truth = self.measured_fixture(summary, cached=False, curves=b"fresh curves")
        ground_truth.assert_called_once_with(directory, {"fixture": True}, self.datasets / "family/safe")
        self.assertFalse(result["cached"])
        self.assertEqual(result["seed_results"], summary["seed_results"])
        self.assertNotIn("seed", result["seed_results"][1])
        for key in ("failed_seeds", "excluded", "n_seeds", "base_seed"):
            self.assertEqual(result[key], summary[key])
        self.assertEqual(result["measurement_files"]["results/curves.npz"]["sha256"],
                         hashlib.sha256(b"fresh curves").hexdigest())
        self.assertEqual(json.loads((directory / "results/summary.json").read_text()), summary)

    def test_fresh_runner_error_marks_cache_status_and_unknown_measurement(self):
        result, directory, ground_truth = self.measured_fixture({}, cached=False, error=RuntimeError("fixture failure"))
        ground_truth.assert_called_once()
        self.assertFalse(result["cached"])
        self.assertEqual(result["error"], "RuntimeError: fixture failure")
        for key in ("mean", "std", "failed_seeds", "excluded", "n_seeds", "base_seed", "seed_results"):
            self.assertIsNone(result[key])
        self.assertEqual(set(result["measurement_files"]), {"candidate_spec.json"})
        self.assertFalse((directory / "results").exists())


if __name__ == "__main__":
    unittest.main()
