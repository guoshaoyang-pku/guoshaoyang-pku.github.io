# KB 题库 release v3

日期：2026-10-04。该 release 供 `soa_async_v1` 的 KB / science 循环使用；题目、分组划分和输入来源都在同目录的 manifest、selection 与 split 文件中。

## 题目与划分

| 来源 | 输入 | 抽样 | train / val / test |
|---|---:|---:|---:|
| `arch170` | 170 | 80 | 80 / 0 / 0 |
| `ranking_v2` | 1,999 | 400 | 280 / 60 / 60 |
| `ranking_v3` | 1,000 | 300 | 210 / 45 / 45 |
| `dataflip500` | 500 | 200 | 200 / 0 / 0 |
| **合计** | — | **980** | **770 / 105 / 105** |

抽样 seed 为 `20261004`。按 group、dataset、candidate set、pair / flip pair 和可追踪的数据生成种子整组划分；同一组不跨 split。`dataflip500` 的成对题目一起保留。无法从输入恢复的共享关系不被假定为已排除。

`arch170` 与 `ranking_v3` 使用 v1.5 gate；`ranking_v2` 保留 legacy gate；`dataflip500` 是共享候选配置上的数据翻转题。不同来源的 gate 不合并解释为同一统计保证。

## 评分

选择题答对得 1 分，答错得 0 分。排序题按预测相对 gold 的逆序对数计分：0、1、2、3 个逆序对分别为 1、0.75、0.5、0.25 分；4 个及以上或无法解析为 0 分。被引用 claim 的 `s += score`、`f += 1-score` 是引用反馈，不能解释成 claim 的真实概率。

## 评测边界

新 holdout 只有 `ranking_v2` 和 `ranking_v3`。`arch170`、`dataflip500` 在旧实验中已有曝光，因此它们只进入 train。当前 loop 关闭最终 test；宏观检查使用 ranking v2/v3 的 105 题 val，每组 3 次重复。任何收益结论都必须注明这一边界。

## 文件与哈希

- `questions.jsonl` — `9ccc03dc273f0ab374bbde1dfbde340282f1489fe3f055020e4009daaafe5973`
- `manifest.json` — `419bcc57dd172a276c328ad7647eda7406fa0648d2eb08a1e618ebfe0215e070`
- `split.json` — `2c05b80c7c5f79edc0fcb7df4fc5f59032a51e292185edad751859bb055b2250`
- `selection.json` — `7994e052fb53493244b2f97f060067bec7c4dbc8664ee1340d684246d75edce1`

完整文件和 source provenance 见 `aiq_bench_repo/releases/kb_science_pool_v3/`；不要用网页文章中的复制表格替代 release 文件。
